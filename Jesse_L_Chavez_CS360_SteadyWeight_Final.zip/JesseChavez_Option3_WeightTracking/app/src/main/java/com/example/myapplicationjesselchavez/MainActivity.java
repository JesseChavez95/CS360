package com.example.myapplicationjesselchavez;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;
import android.provider.Settings;
import android.net.Uri;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

/** Connects the Project Two screens to account-scoped SQLite records. */
public class MainActivity extends Activity {
    private static final int SMS_REQUEST=101;
    private WeightDatabase database;
    private long userId=-1, editingId=-1;
    private int screen=R.layout.activity_login;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); database=new WeightDatabase(this);
        if(state!=null) { userId=state.getLong("user",-1); editingId=state.getLong("editing",-1); screen=state.getInt("screen",screen); }
        show(userId<0?R.layout.activity_login:screen);
    }
    private String text(int id) { return ((EditText)findViewById(id)).getText().toString().trim(); }
    private void message(String text) { Toast.makeText(this,text,Toast.LENGTH_LONG).show(); }
    private void bind(int id,Runnable action) {
        android.view.View view=findViewById(id); if(view!=null) view.setOnClickListener(v->action.run());
    }
    private void show(int layout) {
        screen=layout; setContentView(layout);
        android.view.View root=findViewById(R.id.main);
        root.setOnApplyWindowInsetsListener((v,i)-> { v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom()); return i; }); root.requestApplyInsets();
        bind(R.id.login,()->authenticate(false)); bind(R.id.createAccount,()->authenticate(true));
        bind(R.id.addWeight,()-> { editingId=-1; show(R.layout.activity_entry); });
        bind(R.id.setGoal,()-> { editingId=-1; show(R.layout.activity_entry); findViewById(R.id.goalWeight).requestFocus(); });
        bind(R.id.smsSettings,()->show(R.layout.activity_sms));
        bind(R.id.logout,()-> { userId=-1; editingId=-1; show(R.layout.activity_login); });
        bind(R.id.saveWeight,this::saveWeight); bind(R.id.saveGoal,this::saveGoal);
        bind(R.id.cancelEntry,()->show(R.layout.activity_dashboard));
        bind(R.id.backDashboard,()->show(R.layout.activity_dashboard));
        bind(R.id.allowSms,this::enableSms);
        bind(R.id.declineSms,()-> { ContentValues v=new ContentValues(); v.put("sms",0); database.updateUser(userId,v); smsStatus(); });
        if(layout==R.layout.activity_dashboard) loadGrid();
        if(layout==R.layout.activity_entry) loadEntry();
        if(layout==R.layout.activity_sms) {
            try(Cursor c=database.user(userId)) { if(c.moveToFirst()) ((EditText)findViewById(R.id.phoneNumber)).setText(c.getString(c.getColumnIndexOrThrow("phone"))); }
            smsStatus();
        }
    }
    private void authenticate(boolean create) {
        String username=text(R.id.username);
        // Do not trim passwords: spaces can be intentional parts of a credential.
        String password=((EditText)findViewById(R.id.password)).getText().toString();
        if(username.isEmpty()||password.isEmpty()) { message("Enter a username and password."); return; }
        if(create&&(password.length()<8||username.length()>64)) { message("Use a username up to 64 characters and a password of at least eight characters."); return; }
        findViewById(R.id.login).setEnabled(false); findViewById(R.id.createAccount).setEnabled(false);
        // Password derivation runs away from the UI thread to keep the screen responsive.
        new Thread(()-> {
            long result=-1; String error="Incorrect username or password.";
            try { AccountRepository accounts=new AccountRepository(database); result=create?accounts.create(username,password):accounts.login(username,password); }
            catch(SQLiteConstraintException e) { error="That username already exists."; }
            catch(RuntimeException e) { error="Unable to access accounts. Please try again."; }
            final long id=result; final String notice=error;
            runOnUiThread(()-> { if(isFinishing()||isDestroyed()) return; if(id>=0) { userId=id; show(R.layout.activity_dashboard); } else { message(notice); findViewById(R.id.login).setEnabled(true); findViewById(R.id.createAccount).setEnabled(true); } });
        }).start();
    }
    private TextView cell(String value) {
        TextView v=new TextView(this); v.setText(value); v.setPadding(6,12,6,12); v.setTextSize(14); v.setTextColor(getColor(R.color.ink)); return v;
    }
    private void loadGrid() {
        try(Cursor u=database.user(userId)) { if(u.moveToFirst()) ((TextView)findViewById(R.id.goalSummary)).setText(u.isNull(u.getColumnIndexOrThrow("goal"))?"No goal set":String.format(Locale.US,"%.1f lb",u.getDouble(u.getColumnIndexOrThrow("goal")))); }
        TableLayout grid=findViewById(R.id.weightGrid);
        try(Cursor c=database.weights(userId)) {
            if(c.getCount()==0) { TableRow row=new TableRow(this); row.addView(cell("No entries yet")); grid.addView(row); }
            while(c.moveToNext()) {
                long id=c.getLong(0); String date=c.getString(2); TableRow row=new TableRow(this);
                row.addView(cell(date)); row.addView(cell(String.format(Locale.US,"%.1f",c.getDouble(3))));
                LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.VERTICAL);
                Button edit=new Button(this); edit.setText("Edit"); edit.setContentDescription("Edit weight for "+date); edit.setOnClickListener(v-> { editingId=id; show(R.layout.activity_entry); }); actions.addView(edit);
                Button delete=new Button(this); delete.setText("Delete"); delete.setContentDescription("Delete weight for "+date);
                delete.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Delete weight for "+date+"?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)-> { database.deleteWeight(userId,id); show(R.layout.activity_dashboard); }).show());
                actions.addView(delete); row.addView(actions); grid.addView(row);
            }
        }
    }
    private void loadEntry() {
        ((EditText)findViewById(R.id.entryDate)).setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));
        try(Cursor c=database.weights(userId)) { while(c.moveToNext()) if(c.getLong(0)==editingId) { ((EditText)findViewById(R.id.entryDate)).setText(c.getString(2)); ((EditText)findViewById(R.id.entryWeight)).setText(c.getString(3)); } }
        try(Cursor c=database.user(userId)) { if(c.moveToFirst()&&!c.isNull(c.getColumnIndexOrThrow("goal"))) ((EditText)findViewById(R.id.goalWeight)).setText(c.getString(c.getColumnIndexOrThrow("goal"))); }
    }
    private double positiveWeight(int id) {
        double value=Double.parseDouble(text(id)); if((Double.isNaN(value)||Double.isInfinite(value))||value<=0||value>2000) throw new IllegalArgumentException(); return value;
    }
    private void saveWeight() {
        try {
            String date=text(R.id.entryDate); SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd",Locale.US); format.setLenient(false);
            if(!date.matches("\\d{4}-\\d{2}-\\d{2}")||format.parse(date)==null) throw new IllegalArgumentException();
            database.saveWeight(userId,editingId,date,positiveWeight(R.id.entryWeight)); editingId=-1;
            show(R.layout.activity_dashboard); checkGoal();
        } catch(SQLiteConstraintException e) { message("An entry already exists for that date. Edit that entry instead."); }
        catch(Exception e) { message("Use a real date in YYYY-MM-DD format and a weight above 0 and up to 2000 lb."); }
    }
    private void saveGoal() {
        try {
            double goal=positiveWeight(R.id.goalWeight);
            new AlertDialog.Builder(this).setTitle("Goal direction").setItems(new String[]{"Weight loss: at or below goal","Weight gain: at or above goal"},(d,which)-> {
                ContentValues v=new ContentValues(); v.put("goal",goal); v.put("direction",which==0?-1:1); v.put("alerted",0); database.updateUser(userId,v); show(R.layout.activity_dashboard); message("Goal saved. The next qualifying saved weight can trigger an SMS.");
            }).show();
        } catch(Exception e) { message("Enter a goal above 0 and up to 2000 lb."); }
    }
    private boolean hasSmsPermission() { return checkSelfPermission(Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED; }
    private void enableSms() {
        String phone=text(R.id.phoneNumber).replaceAll("[\\s()\\-]","");
        if(!phone.matches("\\+?[0-9]{3,15}")) { message("Enter a valid mobile number, including country code when needed."); return; }
        if(!getPackageManager().hasSystemFeature(PackageManager.FEATURE_TELEPHONY)) { message(getString(R.string.sms_unavailable)); return; }
        ContentValues v=new ContentValues(); v.put("phone",phone); v.put("sms",1); database.updateUser(userId,v);
        if(hasSmsPermission()) smsStatus();
        else if(!shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS)&&getPreferences(0).getBoolean("requested",false)) {
            new AlertDialog.Builder(this).setMessage("SMS permission is disabled. Enable it in app settings, or keep tracking without SMS.").setNegativeButton("Cancel",null).setPositiveButton("Settings",(d,w)->startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())))).show();
        } else { getPreferences(0).edit().putBoolean("requested",true).apply(); requestPermissions(new String[]{Manifest.permission.SEND_SMS},SMS_REQUEST); }
    }
    private void smsStatus() {
        TextView status=findViewById(R.id.permissionStatus); if(status==null) return;
        try(Cursor c=database.user(userId)) { if(c.moveToFirst()) status.setText(hasSmsPermission()&&c.getInt(c.getColumnIndexOrThrow("sms"))==1?R.string.sms_allowed:R.string.sms_disabled); }
    }
    private void checkGoal() {
        try(Cursor u=database.user(userId); Cursor weights=database.weights(userId)) {
            if(!u.moveToFirst()||!weights.moveToFirst()||u.isNull(u.getColumnIndexOrThrow("goal"))) return;
            double goal=u.getDouble(u.getColumnIndexOrThrow("goal")), weight=weights.getDouble(3);
            boolean reached=u.getInt(u.getColumnIndexOrThrow("direction"))<0?weight<=goal:weight>=goal;
            if(reached&&hasSmsPermission()&&u.getInt(u.getColumnIndexOrThrow("sms"))==1&&u.getInt(u.getColumnIndexOrThrow("alerted"))==0) {
                // Explicit receiver records the modem result even if this Activity is gone.
                ContentValues v=new ContentValues(); v.put("alerted",1); database.updateUser(userId,v);
                Intent result=new Intent(this,SmsResultReceiver.class).putExtra("user",userId).putExtra("goal",goal);
                PendingIntent sent=PendingIntent.getBroadcast(this,(int)userId,result,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                try { android.telephony.SmsManager.getDefault().sendTextMessage(u.getString(u.getColumnIndexOrThrow("phone")),null,getString(R.string.s61),sent,null); message("Goal reached. SMS submitted; delivery depends on mobile service."); }
                catch(RuntimeException e) { v.put("alerted",0); database.updateUser(userId,v); message("Weight saved. SMS unavailable; check permission and mobile service."); }
            }
        }
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(request,permissions,results); if(request==SMS_REQUEST&&userId>=0) { ContentValues v=new ContentValues(); v.put("sms",results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED?1:0); database.updateUser(userId,v); smsStatus(); }
    }
    @Override protected void onResume() { super.onResume(); if(screen==R.layout.activity_sms) smsStatus(); }
    @Override protected void onSaveInstanceState(Bundle state) { state.putLong("user",userId); state.putLong("editing",editingId); state.putInt("screen",screen); super.onSaveInstanceState(state); }
    @Override public void onBackPressed() { if(screen==R.layout.activity_entry||screen==R.layout.activity_sms) show(R.layout.activity_dashboard); else if(screen==R.layout.activity_dashboard) { userId=-1; show(R.layout.activity_login); } else super.onBackPressed(); }
}
