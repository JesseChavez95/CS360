package com.example.myapplicationjesselchavez;

import android.app.Activity;
import android.content.*;
import android.database.Cursor;
import android.widget.Toast;

/** Makes a failed modem submission retryable without blocking weight tracking. */
public final class SmsResultReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent) {
        if(getResultCode()==Activity.RESULT_OK) return;
        try(WeightDatabase db=new WeightDatabase(context); Cursor c=db.user(intent.getLongExtra("user",-1))) {
            if(c.moveToFirst()&&c.getDouble(c.getColumnIndexOrThrow("goal"))==intent.getDoubleExtra("goal",-1)) {
                ContentValues v=new ContentValues(); v.put("alerted",0); db.updateUser(c.getLong(0),v);
            }
        }
        Toast.makeText(context,"SMS failed. Your weight is saved. Check mobile service and save again to retry.",Toast.LENGTH_LONG).show();
    }
}
