package com.example.myapplicationjesselchavez;

import android.content.ContentValues;
import android.database.Cursor;
import android.util.Base64;
import java.security.*;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Stores a unique random salt and a derived password hash, never the original password. */
public final class AccountRepository {
    private final WeightDatabase database;
    public AccountRepository(WeightDatabase database) { this.database=database; }
    private String hash(String password, String salt) {
        PBEKeySpec spec=new PBEKeySpec(password.toCharArray(),Base64.decode(salt,0),120000,256);
        try { return Base64.encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).getEncoded(),Base64.NO_WRAP); }
        catch (Exception e) { throw new IllegalStateException("Password derivation unavailable",e); }
        finally { spec.clearPassword(); }
    }
    public long create(String username,String password) {
        byte[] salt=new byte[16]; new SecureRandom().nextBytes(salt);
        String encoded=Base64.encodeToString(salt,Base64.NO_WRAP);
        ContentValues v=new ContentValues(); v.put("username",username); v.put("salt",encoded); v.put("password_hash",hash(password,encoded));
        return database.getWritableDatabase().insertOrThrow("users",null,v);
    }
    public long login(String username,String password) {
        try(Cursor c=database.getReadableDatabase().rawQuery("SELECT _id,salt,password_hash FROM users WHERE username=?",new String[]{username})) {
            if(!c.moveToFirst()) return -1;
            return MessageDigest.isEqual(hash(password,c.getString(1)).getBytes(java.nio.charset.StandardCharsets.UTF_8),c.getString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8))?c.getLong(0):-1;
        }
    }
}
