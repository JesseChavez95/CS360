package com.example.myapplicationjesselchavez;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;

/** Owns persistent account, weight and notification data. All record access is user scoped. */
public final class WeightDatabase extends SQLiteOpenHelper {
    public WeightDatabase(Context context) { super(context, "steady_weight.db", null, 1); }
    @Override public void onConfigure(SQLiteDatabase db) { db.setForeignKeyConstraintsEnabled(true); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (_id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, salt TEXT NOT NULL, password_hash TEXT NOT NULL, goal REAL, direction INTEGER NOT NULL DEFAULT -1, phone TEXT NOT NULL DEFAULT '', sms INTEGER NOT NULL DEFAULT 0, alerted INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE weights (_id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(_id) ON DELETE CASCADE, date TEXT NOT NULL, weight REAL NOT NULL CHECK(weight>0), UNIQUE(user_id,date))");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Add non-destructive migrations here when the schema version increases.
        throw new IllegalStateException("No migration defined");
    }
    public Cursor user(long id) { return getReadableDatabase().rawQuery("SELECT * FROM users WHERE _id=?", new String[]{""+id}); }
    public Cursor weights(long user) { return getReadableDatabase().rawQuery("SELECT * FROM weights WHERE user_id=? ORDER BY date DESC", new String[]{""+user}); }
    public void updateUser(long user, ContentValues values) { getWritableDatabase().update("users", values, "_id=?", new String[]{""+user}); }
    public long saveWeight(long user, long id, String date, double weight) {
        ContentValues v = new ContentValues(); v.put("user_id",user); v.put("date",date); v.put("weight",weight);
        if(id<0) return getWritableDatabase().insertOrThrow("weights",null,v);
        return getWritableDatabase().update("weights",v,"_id=? AND user_id=?",new String[]{""+id,""+user});
    }
    public void deleteWeight(long user,long id) { getWritableDatabase().delete("weights","_id=? AND user_id=?",new String[]{""+id,""+user}); }
}
